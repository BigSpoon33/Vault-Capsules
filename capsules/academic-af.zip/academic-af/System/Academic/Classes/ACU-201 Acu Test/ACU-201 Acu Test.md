---
categories:
  - "[[Classes]]"
term: "[[Spring 2026]]"
course-code: ACU-201
course-name: Acu Test
tags:
  - task
  - class
status: open
priority: normal
scheduled: 2026-01-05T18:00
recurrence: DTSTART:20260105T180000Z;FREQ=WEEKLY;BYDAY=MO,WE;UNTIL=20260419
recurrence_anchor: scheduled
cssclasses: dashboard
instructor: Dr. Hsiao
semester: Spring 2026
grade: A
---

# 📚 ACU-201 - Acu Test

```datacorejsx
const { ClassView } = await dc.require(dc.fileLink("System/Scripts/Widgets/dc-classView.jsx"));
return <ClassView />;
```

![[Coursework.base#By Class|embed-clean]]