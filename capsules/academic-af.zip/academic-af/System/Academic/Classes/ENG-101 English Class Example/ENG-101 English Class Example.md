---
categories:
  - "[[Classes]]"
term: "[[Spring 2026]]"
course-code: ENG-101
course-name: English Class Example
tags:
  - task
  - class
status: open
priority: normal
scheduled: 2026-01-05T18:00
recurrence: DTSTART:20260105T180000Z;FREQ=WEEKLY;BYDAY=MO,WE;UNTIL=20260419
recurrence_anchor: scheduled
cssclasses: dashboard
semester: ""
---

# 📚 ENG-101 - English Class Example

```datacorejsx
const { ClassView } = await dc.require(dc.fileLink("System/Scripts/Widgets/dc-classView.jsx"));
return <ClassView />;
```

![[Coursework.base#By Class|embed-clean]]