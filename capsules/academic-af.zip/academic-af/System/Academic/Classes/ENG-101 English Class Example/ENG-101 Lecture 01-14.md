---
tags: 
  - note
  - lecture
categories:
  - "[[Coursework]]"
class: "[[ENG-101 English Class Example]]"
type: note
status: done
date: 2026-01-14
topics: []
---

# 🎙️ Lecture 01-14

```datacorejsx
const { CourseworkView } = await dc.require(dc.fileLink("System/Scripts/Widgets/dc-courseworkView.jsx"));
return <CourseworkView />;
```

## 🧠 Key Concepts

## 📝 Notes

> [!tip] Summary

## 🔗 References