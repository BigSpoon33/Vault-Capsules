---
categories:
  - "[[Classes]]"
term: "[[Spring 2026]]"
course-code: CSS-101
course-name: css snippets
instructor: Dr. Hsiao
credits: 3
semester: Spring 2026
# TASKNOTES CONFIGURATION
tags: [task, class]
status: open
priority: normal
scheduled: 2026-01-05T18:00
recurrence: DTSTART:20260105T180000Z;FREQ=WEEKLY;BYDAY=MO,WE;UNTIL=20260419
recurrence_anchor: scheduled
# END TASKNOTES
cssclasses: dashboard
---

# 📚 CSS-101 - css snippets

```datacorejsx
const { ClassView } = await dc.require(dc.fileLink("System/Scripts/Widgets/dc-classView.jsx"));
return <ClassView />;
```

![[System/Academic/Classes/CSS-101 css snippets/CSS-101 Exam 01-17.md]]