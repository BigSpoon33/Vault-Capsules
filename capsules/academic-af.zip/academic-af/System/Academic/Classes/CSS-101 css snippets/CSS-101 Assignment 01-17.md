---
tags: 
  - task 
  - assignment
categories:
  - "[[Coursework]]"
class: "[[CSS-101 css snippets]]"
type: assignment
status: none
priority: normal
due: 2026-01-24
created: 2026-01-17
grade: 
---

# 📝 Assignment 01-17

```datacorejsx
const { CourseworkView } = await dc.require(dc.fileLink("System/Scripts/Widgets/dc-courseworkView.jsx"));
return <CourseworkView />;
```
## 📋 Requirements

- [ ]
    

## ✍️ Work


