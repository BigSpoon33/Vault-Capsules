---
tags: 
  - note
  - lecture
categories:
  - "[[Coursework]]"
class: "[[CSS-101 css snippets]]"
type: note
status: done
date: 2026-01-17
topics: []
---

# 🎙️ Lecture 01-17

```datacorejsx
const { CourseworkView } = await dc.require(dc.fileLink("System/Scripts/Widgets/dc-courseworkView.jsx"));
return <CourseworkView />;
```

## 🧠 Key Concepts

## 📝 Notes

> [!tip] Summary

## 🔗 References