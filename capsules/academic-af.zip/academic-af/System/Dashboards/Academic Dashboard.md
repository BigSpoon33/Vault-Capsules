---
cssclasses: 
  - noyaml
tags:
  - dashboards
  - academic
due: 2025-12-31
status: todo
priority: high
grade: ""
type: assignment
image: 
---

<a href='https://ko-fi.com/M4M11S2NNW' target='_blank'><img height='36' width ='124' style='border:0px;height:36px;' src='https://storage.ko-fi.com/cdn/kofi6.png?v=6' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a>

```datacorejsx
const { AcademicDashboard } = await dc.require(dc.fileLink("System/Scripts/Widgets/dc-academicDashboard.jsx"));
return <AcademicDashboard />;
```
![[System/Academic/Classes/CSS-101 css snippets/CSS-101 css snippets.md]]

