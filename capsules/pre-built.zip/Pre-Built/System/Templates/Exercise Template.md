---
categories:
  - "[[Exercise]]"
icon: ""
type: []
target: []
equipment: []
duration:
sets:
reps:
weight:
rating:
created: {{date}}
last:
---

## Description

Brief description of this exercise and what it targets.

## Instructions

1. Starting position
2. Movement execution
3. Return to starting position
4. Breathing pattern

## Form Tips

- Key form cue #1
- Key form cue #2
- Common mistakes to avoid
- Safety considerations

## Variations

- Easier variation:
- Harder variation:
- Alternative equipment:

## Notes

- Personal observations
- Progress tracking
- Modifications that work for you
