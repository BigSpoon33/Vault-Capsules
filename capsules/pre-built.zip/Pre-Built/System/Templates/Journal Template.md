---
created: {{date}}
tags:
  - journal
---
