---
tags:
  - categories
image: Pasted image 20251227201000.png
---

# 💪 Exercise Library

![[Exercise.base#All Exercises]]

---
![[Pasted image 20251227201000.png]]