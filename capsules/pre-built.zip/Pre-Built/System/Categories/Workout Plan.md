---
created: 2025-12-22
tags:
  - categories
image: Pasted image 20251227200902.png
---

![[Workout Plans.base]]

![[Pasted image 20251227200902.png]]