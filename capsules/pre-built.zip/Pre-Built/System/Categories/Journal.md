---
image: [[Pasted image 20251210012710.png]]
tags:
  - categories
---

![[Journal.base]]

![[Pasted image 20251210012707.png]]