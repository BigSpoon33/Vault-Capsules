---
created: 2025-12-28
tags:
  - planners
cssclasses:
  - dashboard
  - noyaml
icon: 
schedule-thursday: "[[New Workout]]"
schedule-friday: "[[New Workout4]]"
schedule-tuesday: "[[Legs]]"
schedule-saturday: "[[Push Day]]"
---

```datacorejsx
const script = await dc.require(dc.fileLink("System/Scripts/Widgets/dc-weeklyWorkout.jsx"));
return function View() { return script.Func(); }
```

---


<a href='https://ko-fi.com/M4M11S2NNW' target='_blank'><img height='36' width ='108' style='border:0px;height:36px;' src='https://storage.ko-fi.com/cdn/kofi6.png?v=6' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a>
